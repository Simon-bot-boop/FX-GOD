import React from 'react'
import ReactDOM from 'react-dom/client'
import FxGodHomepage from './FxGodHomepage'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <FxGodHomepage />
  </React.StrictMode>,
)
